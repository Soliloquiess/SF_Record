package com.ssafy.util;

public class PageConstance {

	public static int LIST_SIZE = 3;
	public static int NAVI_SIZE = 10;
	
}
