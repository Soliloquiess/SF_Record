package board.service;

import board.dto.UserDto;

public interface UserService {
	public int userRegister(UserDto userDto);
}
