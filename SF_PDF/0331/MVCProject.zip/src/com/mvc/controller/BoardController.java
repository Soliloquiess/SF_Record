package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.service.BoardService;
import com.mvc.service.BoardServiceImpl;
import com.mvc.vo.Board;

//FrontController에게서 요청을 넘겨 받아 Service한테 작업을 넘김
public class BoardController {
	
	
	
	public BoardController() {
		
	}
	
	
	public void list(HttpServletRequest request, HttpServletResponse response) {
		//Service한테 data 받음
		//request에 데이터 저장
		//view로 넘어가기(forward 방식)			
	}	

}









