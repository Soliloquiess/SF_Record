package com.mvc.service;

import java.util.ArrayList;

import com.mvc.dao.BoardDAO;
import com.mvc.dao.BoardDAOImpl;
import com.mvc.vo.Board;

//BoardService의 메소드를 구현한 객체.
//Controller에서 들어온 요청을 실제로 처리하는 객체
//DAO에게 요청사항을 전달함
public class BoardServiceImpl implements BoardService{
	
	
	public BoardServiceImpl() {
		
	}

	@Override
	public ArrayList<Board> selectAll() {		
		return null;
	}

	@Override
	public Board selectOne(String num) {
		return null;
	}

	@Override
	public void insert(Board b) {}

	@Override
	public void delete(String num) {}

}
