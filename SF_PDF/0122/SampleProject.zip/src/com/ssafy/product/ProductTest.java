package com.ssafy.product;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
