package com.ssafy.product;

public class Product {

}
