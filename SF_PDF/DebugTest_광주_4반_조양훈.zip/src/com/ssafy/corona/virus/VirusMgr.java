package com.ssafy.corona.virus;

public interface VirusMgr {
	void add(Virus v) throws DuplicatedException, NotFoundException;
	Virus[] search();
	Virus search(String name) throws NotFoundException;
//	void search(Virus v);
}