package com.ssafy.corona.person;

import java.util.ArrayList;
import java.util.List;
//
//import com.test.Book;
//import com.test.Magazine;

public interface PersonMgr  {
	void add(Person p);
	List<Person> search();
	Person search(String name);
	void delete(String name);
	void load();
	void save();
	ArrayList<Person> getList();	

	
}