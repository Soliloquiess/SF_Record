package com.ssafy.sort;

import java.util.Arrays;
/**
 * @author THKim
 */
public class SortTest {

	public static void main(String[] args) {

		int[] list = {69,10,2,2,16};
//		int[] list = {1,2,3,4,5};
		System.out.println(Arrays.toString(list));
//		Sort.countingSort(list);
		Sort.mergeSort(list);
		System.out.println(Arrays.toString(list));
	}

}
