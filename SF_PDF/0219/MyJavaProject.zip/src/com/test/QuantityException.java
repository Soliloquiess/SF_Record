package com.test;

public class QuantityException {

	public QuantityException() {
		super("수량이 부족합니다.");
	}

}
