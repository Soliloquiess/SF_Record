package com.test;

 /* 도서 정보를 나타내는 클래스
   encapsulation
   constructor
   getter, setter
   toString
     직렬화 객체
 */

public class Book  {	
	
	 String isbn;	
	 String title;	
	 String author;		
	 String publisher;
	 int price;	
	 String desc;	
	 int quantity;
	 
	/** 기본 생성자 */
	
	/** 도서 정보를 모두 받아 생성하는 생성자 */
	
	
}

