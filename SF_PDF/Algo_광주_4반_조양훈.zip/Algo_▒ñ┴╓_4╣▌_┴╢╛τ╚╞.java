package Main;

import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		if(1>T ||T>10) {return;}
		int A,B,N,X,K,answer,q;
		
		for(int i = 1; i<=T;i++)
		{
			 N = sc.nextInt();
			 X = sc.nextInt();
			 K = sc.nextInt();

			 int arr[] = new int[200001];
			 arr[X] =1;
			
			for(int j=1; j<=K;j++)
			{
				 A = sc.nextInt();
				 B = sc.nextInt();
				
				int temp=arr[A];
				arr[A]=arr[B];
				arr[B]=temp;
			}
			for(q =1;q<10;q++) {
				if(arr[q]==1) {
					System.out.println("#"+i+" "+q);
				}
			}
		}
		
		
		
	}
}

