package Main;

import java.util.Scanner;

public class Main2 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int N,S,M;	//N은 동아리 수 S는 팀원 3명 능력 합에 따른 가입조건 M은 개인 능력치에 따른 가입조건
		int i,j;
		int arr[] = new int[4000];
		int sum=0;
		int answer=0;
		N= sc.nextInt();
		S= sc.nextInt();
		M= sc.nextInt();
		
		for (i=1;i<=N;i++) {
			for(j= 1; j<=3;j++) {
				
				arr[j]=sc.nextInt();
				
				if(arr[j]>=M) {
					sum = sum+arr[j];
				}
				else
				{
					break;
				}
				
			}
			if(sum>S) {
				for(int k =1; k<=3;k++)
				System.out.print(arr[k]+" "+"\n");
				answer++;
			}
			
			sum =0;
		}
		System.out.println(answer);	//문제 잘못 봤네요 ㅠ
	}
}
