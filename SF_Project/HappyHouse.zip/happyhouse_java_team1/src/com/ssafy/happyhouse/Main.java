package com.ssafy.happyhouse;

import com.ssafy.happyhouse.view.HouseInfoView;
//gogo888888aa

public class Main {
	public static void main(String[] args) {
		new HouseInfoView();
	}
}
