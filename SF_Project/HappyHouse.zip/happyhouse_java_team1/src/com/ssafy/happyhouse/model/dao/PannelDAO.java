package com.ssafy.happyhouse.model.dao;

import java.util.List;
import com.ssafy.happyhouse.model.dto.PannelInfo;

public interface PannelDAO {
	void create();
	
	List<PannelInfo> search(String dong);
	
}
